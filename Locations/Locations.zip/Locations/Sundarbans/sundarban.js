let topBtn = document.getElementById("topBtn");

window.onscroll = function () {
  topBtn.style.display = 
    (document.documentElement.scrollTop > 200) ? "block" : "none";
};

function topFunction() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}
